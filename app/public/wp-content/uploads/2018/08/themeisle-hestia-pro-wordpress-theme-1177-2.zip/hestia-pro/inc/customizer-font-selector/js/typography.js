/**
 * JS File for Typhography control
 *
 * @package Hestia
 */
( function($) {

	$( document ).ready(
		function () {

			$( '.hestia-typography-select' ).hestiaSelect();

		}
	);

} )( jQuery );
