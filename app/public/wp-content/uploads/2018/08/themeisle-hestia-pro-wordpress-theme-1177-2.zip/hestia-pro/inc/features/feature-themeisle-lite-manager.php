<?php
/**
 * Themeisle Lite Feature Manager
 *
 * @package Hestia
 * @since 1.1.7
 */

/* Add a flag for themeisle lite version */
define( 'HESTIA_THEMEISLE_LITE', true );
